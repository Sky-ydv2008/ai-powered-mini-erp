(() => {
    let deferredInstallPrompt = null;

    const createInstallButton = () => {
        if (document.getElementById("bharat-install-app")) return;

        const button = document.createElement("button");
        button.id = "bharat-install-app";
        button.type = "button";
        button.textContent = "Install Bharat App";
        Object.assign(button.style, {
            position: "fixed",
            right: "20px",
            bottom: "20px",
            zIndex: "99999",
            border: "0",
            borderRadius: "12px",
            padding: "12px 18px",
            background: "linear-gradient(135deg,#6366f1,#8b5cf6)",
            color: "#fff",
            fontWeight: "700",
            fontSize: "14px",
            cursor: "pointer",
            boxShadow: "0 10px 30px rgba(0,0,0,.35)"
        });

        button.addEventListener("click", async () => {
            if (!deferredInstallPrompt) {
                alert("Chrome will show the install option when this website meets the install requirements. You can also use Chrome menu → Install Bharat.");
                return;
            }
            deferredInstallPrompt.prompt();
            const result = await deferredInstallPrompt.userChoice;
            if (result.outcome === "accepted") button.remove();
            deferredInstallPrompt = null;
        });

        document.body.appendChild(button);
        return button;
    };

    const registerServiceWorker = async () => {
        if (!("serviceWorker" in navigator)) return;
        try {
            const registration = await navigator.serviceWorker.register("/sw.js", { scope: "/" });
            registration.addEventListener("updatefound", () => {
                const worker = registration.installing;
                if (!worker) return;
                worker.addEventListener("statechange", () => {
                    if (worker.state === "installed" && navigator.serviceWorker.controller) {
                        worker.postMessage({ type: "SKIP_WAITING" });
                    }
                });
            });
        } catch (error) {
            console.warn("Bharat PWA service worker registration failed:", error);
        }
    };

    window.addEventListener("beforeinstallprompt", event => {
        event.preventDefault();
        deferredInstallPrompt = event;
        const button = createInstallButton();
        if (button) button.style.display = "block";
    });

    window.addEventListener("appinstalled", () => {
        deferredInstallPrompt = null;
        document.getElementById("bharat-install-app")?.remove();
    });

    window.addEventListener("DOMContentLoaded", () => {
        registerServiceWorker();
        if (window.matchMedia("(display-mode: standalone)").matches) {
            document.documentElement.classList.add("pwa-installed");
        }
    });
})();
