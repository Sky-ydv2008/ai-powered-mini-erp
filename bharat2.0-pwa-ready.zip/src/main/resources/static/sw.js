const CACHE_NAME = "bharat-pwa-v1";
const APP_SHELL = [
  "/ai-insights.html",
  "/assistant.html",
  "/css/dashboard.css",
  "/css/forms.css",
  "/css/responsive.css",
  "/css/style.css",
  "/css/tables.css",
  "/customers.html",
  "/dashboard.html",
  "/expenses.html",
  "/favicon.png",
  "/icons/apple-touch-icon.png",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
  "/index.html",
  "/inventory.html",
  "/js/ai.js",
  "/js/api.js",
  "/js/assistant.js",
  "/js/auth.js",
  "/js/charts.js",
  "/js/customers.js",
  "/js/dashboard.js",
  "/js/expenses.js",
  "/js/inventory.js",
  "/js/products.js",
  "/js/purchases.js",
  "/js/reports.js",
  "/js/sales.js",
  "/js/suppliers.js",
  "/js/utils.js",
  "/login.html",
  "/manifest.json",
  "/products.html",
  "/purchases.html",
  "/reports.html",
  "/sales.html",
  "/settings.html",
  "/suppliers.html"
];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("message", event => {
  if (event.data && event.data.type === "SKIP_WAITING") self.skipWaiting();
});

self.addEventListener("fetch", event => {
  const request = event.request;
  const url = new URL(request.url);

  if (request.method !== "GET") return;
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith("/api/")) return;

  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then(response => {
          const copy = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
          return response;
        })
        .catch(() => caches.match(request).then(cached => cached || caches.match("/login.html")))
    );
    return;
  }

  event.respondWith(
    caches.match(request).then(cached => {
      const network = fetch(request).then(response => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
        }
        return response;
      }).catch(() => cached);
      return cached || network;
    })
  );
});
