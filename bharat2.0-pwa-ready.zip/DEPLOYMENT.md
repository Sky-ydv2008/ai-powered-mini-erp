# Bharat — Chrome Installable PWA

## Local test

1. Install Java 21 and Maven.
2. Run:
   `mvn spring-boot:run`
3. Open:
   `http://localhost:3000`
4. In Chrome, test **Install Bharat** from the address bar or Chrome menu.

## Deploy to Render

This repository includes `Dockerfile` and `render.yaml`.

1. Push this project to GitHub.
2. In Render, create a new Blueprint or Web Service from the GitHub repository.
3. Render will use the Dockerfile.
4. Wait for deployment.
5. Open the HTTPS URL in Chrome.
6. Chrome should offer **Install Bharat** when PWA installability checks pass.

## Important

- The PWA requires HTTPS in production. `localhost` is also allowed for local testing.
- API calls are deliberately not cached by the service worker.
- The service worker caches the frontend shell and static assets.
- The app starts at `/login.html`.
- Render's free environment does not provide durable local H2 storage. For production data persistence, configure an external database or suitable persistent storage.
